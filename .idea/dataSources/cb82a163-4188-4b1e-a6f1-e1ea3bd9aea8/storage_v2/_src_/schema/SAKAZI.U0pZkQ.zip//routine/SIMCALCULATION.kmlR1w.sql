create FUNCTION SimCalculation (MID1 NUMBER, MID2 NUMBER, maximal_distance NUMBER) RETURN FLOAT IS
	twoItemsDistance FLOAT;
	mid1prodYear NUMBER;
	mid2prodYear NUMBER;
BEGIN
	SELECT PROD_YEAR INTO mid1prodYear FROM MediaItems WHERE MID=MID1;
	SELECT PROD_YEAR INTO mid2prodYear FROM MediaItems WHERE MID=MID2;
	twoItemsDistance:=power(mid1prodYear-mid2prodYear,2);
	RETURN (1-(twoItemsDistance/maximal_distance));
END SimCalculation;
/

