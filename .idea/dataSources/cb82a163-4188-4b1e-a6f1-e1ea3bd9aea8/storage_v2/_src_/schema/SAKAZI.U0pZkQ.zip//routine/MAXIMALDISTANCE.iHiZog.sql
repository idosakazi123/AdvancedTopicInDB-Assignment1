create FUNCTION MaximalDistance RETURN NUMBER IS
	maxProdYear NUMBER;
	minProdYear NUMBER;
BEGIN
	SELECT MAX(PROD_YEAR) INTO maxProdYear FROM MediaItems;
	SELECT MIN(PROD_YEAR) INTO minProdYear FROM MediaItems;
	RETURN power(maxProdYear-minProdYear,2);
END MaximalDistance;
/

