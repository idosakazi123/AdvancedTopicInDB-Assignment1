create trigger AUTOINCREMENT
  before insert
  on MEDIAITEMS
  for each row
  DECLARE
	maxIndex NUMBER;
BEGIN
	SELECT MAX(MID) INTO maxIndex FROM MediaItems;  -- inserting the index of the new record
		IF maxIndex IS NOT NULL THEN
			:new.MID:=maxIndex+1;
		ELSE
			:new.MID:=0;
		END IF;

	:new.TITLE_LENGTH:=LENGTH(:new.TITLE);  -- seting the length of the title
END;
/

